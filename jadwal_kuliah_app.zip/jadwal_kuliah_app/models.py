from database import get_db

def get_courses_for_lecturer(lecturer_id):
    db = get_db()
    courses = db.execute("""
        SELECT c.*, u.name AS pj_name, u.email AS pj_email,
               s.id AS schedule_id, s.day, s.start_time, s.end_time, s.room, s.status AS schedule_status, s.notes AS schedule_notes, s.updated_at AS schedule_updated_at,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) AS student_count
        FROM courses c
        LEFT JOIN users u ON c.pj_id = u.id
        LEFT JOIN schedules s ON c.id = s.course_id
        WHERE c.lecturer_id = ?
        ORDER BY c.code ASC
    """, (lecturer_id,)).fetchall()
    db.close()
    return courses

def get_courses_for_pj(pj_id):
    db = get_db()
    courses = db.execute("""
        SELECT c.*, u.name AS lecturer_name, u.email AS lecturer_email,
               s.id AS schedule_id, s.day, s.start_time, s.end_time, s.room, s.status AS schedule_status, s.notes AS schedule_notes, s.updated_at AS schedule_updated_at,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) AS student_count
        FROM courses c
        LEFT JOIN users u ON c.lecturer_id = u.id
        LEFT JOIN schedules s ON c.id = s.course_id
        WHERE c.pj_id = ?
        ORDER BY c.code ASC
    """, (pj_id,)).fetchall()
    db.close()
    return courses

def get_student_dashboard_data(student_id):
    db = get_db()
    # Mata kuliah yang diambil mahasiswa
    enrolled_courses = db.execute("""
        SELECT c.*, ul.name AS lecturer_name, upj.name AS pj_name,
               s.id AS schedule_id, s.day, s.start_time, s.end_time, s.room, s.status AS schedule_status, s.notes AS schedule_notes, s.updated_at AS schedule_updated_at,
               (SELECT COUNT(*) FROM schedule_history WHERE course_id = c.id) AS history_count
        FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        LEFT JOIN users ul ON c.lecturer_id = ul.id
        LEFT JOIN users upj ON c.pj_id = upj.id
        LEFT JOIN schedules s ON c.id = s.course_id
        WHERE e.user_id = ?
        ORDER BY s.day ASC, s.start_time ASC
    """, (student_id,)).fetchall()

    # Semua mata kuliah yang tersedia untuk enroll
    all_courses = db.execute("""
        SELECT c.*, ul.name AS lecturer_name,
               (SELECT 1 FROM enrollments WHERE user_id = ? AND course_id = c.id) AS is_enrolled
        FROM courses c
        LEFT JOIN users ul ON c.lecturer_id = ul.id
        ORDER BY c.code ASC
    """, (student_id,)).fetchall()

    # Tugas-tugas aktif dari mata kuliah yang diambil
    assignments = db.execute("""
        SELECT a.*, c.code AS course_code, c.name AS course_name, u.name AS creator_name,
               (SELECT COUNT(*) FROM assignment_reminders WHERE assignment_id = a.id) AS reminder_count
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        JOIN enrollments e ON c.id = e.course_id
        LEFT JOIN users u ON a.created_by = u.id
        WHERE e.user_id = ?
        ORDER BY a.deadline ASC
    """, (student_id,)).fetchall()

    # Riwayat perubahan jadwal terbaru
    recent_changes = db.execute("""
        SELECT h.*, c.code AS course_code, c.name AS course_name
        FROM schedule_history h
        JOIN courses c ON h.course_id = c.id
        JOIN enrollments e ON c.id = e.course_id
        WHERE e.user_id = ?
        ORDER BY h.created_at DESC
        LIMIT 10
    """, (student_id,)).fetchall()

    db.close()
    return enrolled_courses, all_courses, assignments, recent_changes

def get_course_detail(course_id):
    db = get_db()
    course = db.execute("""
        SELECT c.*, ul.name AS lecturer_name, ul.email AS lecturer_email,
               upj.name AS pj_name, upj.email AS pj_email,
               s.id AS schedule_id, s.day, s.start_time, s.end_time, s.room, s.status AS schedule_status, s.notes AS schedule_notes, s.updated_at AS schedule_updated_at
        FROM courses c
        LEFT JOIN users ul ON c.lecturer_id = ul.id
        LEFT JOIN users upj ON c.pj_id = upj.id
        LEFT JOIN schedules s ON c.id = s.course_id
        WHERE c.id = ?
    """, (course_id,)).fetchone()

    assignments = db.execute("""
        SELECT a.*, u.name AS creator_name,
               (SELECT COUNT(*) FROM assignment_reminders WHERE assignment_id = a.id) AS reminder_count
        FROM assignments a
        LEFT JOIN users u ON a.created_by = u.id
        WHERE a.course_id = ?
        ORDER BY a.deadline ASC
    """, (course_id,)).fetchall()

    students = db.execute("""
        SELECT u.id, u.name, u.identifier, u.email, e.enrolled_at
        FROM users u
        JOIN enrollments e ON u.id = e.user_id
        WHERE e.course_id = ?
        ORDER BY u.identifier ASC
    """, (course_id,)).fetchall()

    history = db.execute("""
        SELECT * FROM schedule_history
        WHERE course_id = ?
        ORDER BY created_at DESC
    """, (course_id,)).fetchall()

    db.close()
    return course, assignments, students, history

def get_admin_overview():
    db = get_db()
    stats = {
        'total_courses': db.execute("SELECT COUNT(*) as c FROM courses").fetchone()['c'],
        'total_dosen': db.execute("SELECT COUNT(*) as c FROM users WHERE role = 'dosen'").fetchone()['c'],
        'total_mahasiswa': db.execute("SELECT COUNT(*) as c FROM users WHERE role = 'mahasiswa'").fetchone()['c'],
        'total_pj': db.execute("SELECT COUNT(*) as c FROM users WHERE role = 'pj'").fetchone()['c'],
        'total_assignments': db.execute("SELECT COUNT(*) as c FROM assignments").fetchone()['c'],
        'total_emails': db.execute("SELECT COUNT(*) as c FROM email_outbox").fetchone()['c']
    }
    db.close()
    return stats

def get_all_users_list(filter_role=None):
    db = get_db()
    if filter_role:
        users = db.execute("SELECT * FROM users WHERE role = ? ORDER BY id DESC", (filter_role,)).fetchall()
    else:
        users = db.execute("SELECT * FROM users ORDER BY role ASC, id DESC").fetchall()
    db.close()
    return users

def get_all_courses_with_details():
    db = get_db()
    courses = db.execute("""
        SELECT c.*, ul.name AS lecturer_name, upj.name AS pj_name,
               s.id AS schedule_id, s.day, s.start_time, s.end_time, s.room, s.status AS schedule_status, s.notes AS schedule_notes,
               (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) AS student_count
        FROM courses c
        LEFT JOIN users ul ON c.lecturer_id = ul.id
        LEFT JOIN users upj ON c.pj_id = upj.id
        LEFT JOIN schedules s ON c.id = s.course_id
        ORDER BY c.code ASC
    """).fetchall()
    db.close()
    return courses

def get_lecturers_list():
    db = get_db()
    lecturers = db.execute("SELECT id, name, identifier, email FROM users WHERE role = 'dosen' ORDER BY name ASC").fetchall()
    db.close()
    return lecturers

def get_pjs_list():
    db = get_db()
    pjs = db.execute("SELECT id, name, identifier, email FROM users WHERE role = 'pj' ORDER BY name ASC").fetchall()
    db.close()
    return pjs

def create_course_with_schedule(code, name, lecturer_id, pj_id, semester, day, start_time, end_time, room, admin_id):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        INSERT INTO courses (code, name, lecturer_id, pj_id, semester)
        VALUES (?, ?, ?, ?, ?)
    """, (code, name, lecturer_id if lecturer_id else None, pj_id if pj_id else None, semester))
    new_course_id = cursor.lastrowid

    cursor.execute("""
        INSERT INTO schedules (course_id, day, start_time, end_time, room, status, notes, last_modified_by)
        VALUES (?, ?, ?, ?, ?, 'Normal', 'Jadwal perkuliahan baru', ?)
    """, (new_course_id, day, start_time, end_time, room, admin_id))
    db.commit()
    db.close()
    return new_course_id

def delete_course(course_id):
    db = get_db()
    db.execute("DELETE FROM courses WHERE id = ?", (course_id,))
    db.commit()
    db.close()

def create_user(name, email, identifier, role, password_hash):
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        INSERT INTO users (name, email, identifier, role, password_hash)
        VALUES (?, ?, ?, ?, ?)
    """, (name, email, identifier, role, password_hash))
    new_user_id = cursor.lastrowid
    db.commit()
    db.close()
    return new_user_id

def delete_user(user_id):
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    db.close()
