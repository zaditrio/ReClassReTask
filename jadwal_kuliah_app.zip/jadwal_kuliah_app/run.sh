#!/bin/bash
# Script peluncuran aplikasi KampusScheduler

cd "$(dirname "$0")"

if [ -d "venv" ]; then
    echo "Menggunakan Python Virtual Environment..."
    ./venv/bin/python app.py
else
    echo "Menggunakan Python sistem..."
    python3 app.py
fi
