import unittest
import os
from app import app
from database import get_db, init_db
from seed_data import seed
from services.calendar_service import (
    parse_schedule_datetimes,
    generate_gcal_link,
    generate_ics_content
)
from services.email_service import (
    notify_schedule_change,
    notify_new_assignment,
    notify_assignment_reminder
)

class KampusSchedulerTestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()

    def test_database_and_seed(self):
        db = get_db()
        user_count = db.execute("SELECT COUNT(*) as c FROM users").fetchone()['c']
        course_count = db.execute("SELECT COUNT(*) as c FROM courses").fetchone()['c']
        schedule_count = db.execute("SELECT COUNT(*) as c FROM schedules").fetchone()['c']
        db.close()

        self.assertGreaterEqual(user_count, 6, "Seharusnya ada minimal 6 pengguna demo")
        self.assertGreaterEqual(course_count, 3, "Seharusnya ada minimal 3 mata kuliah")
        self.assertGreaterEqual(schedule_count, 3, "Seharusnya ada jadwal perkuliahan")

    def test_calendar_service(self):
        start_dt, end_dt = parse_schedule_datetimes("Senin", "08:00", "10:30")
        self.assertEqual(start_dt.hour, 8)
        self.assertEqual(end_dt.hour, 10)
        self.assertEqual(end_dt.minute, 30)

        # Cek Google Calendar link
        link = generate_gcal_link("Kuliah Pemrograman Web", "Catatan kuliah", "Lab 3", start_dt, end_dt)
        self.assertIn("calendar.google.com/calendar/render", link)
        self.assertIn("action=TEMPLATE", link)
        self.assertIn("Kuliah+Pemrograman+Web", link)

        # Cek .ics generator
        ics = generate_ics_content("uid-123", "Kuliah Pemrograman Web", "Catatan", "Lab 3", start_dt, end_dt)
        self.assertIn("BEGIN:VCALENDAR", ics)
        self.assertIn("METHOD:REQUEST", ics)
        self.assertIn("SUMMARY:Kuliah Pemrograman Web", ics)
        self.assertIn("END:VCALENDAR", ics)

    def test_auth_login_roles(self):
        # Test Login Dosen
        res = self.client.post('/login', data={
            'email': 'dosen1@kampus.ac.id',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Dashboard Dosen", res.data)

        # Test Logout
        res = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Masuk ke Reclass.UM", res.data)

        # Test Login Mahasiswa
        res = self.client.post('/login', data={
            'email': 'mhs1@mhs.kampus.ac.id',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Dashboard Perkuliahan Mahasiswa", res.data)

    def test_schedule_change_and_email_notification(self):
        db = get_db()
        dosen = db.execute("SELECT id FROM users WHERE role = 'dosen' LIMIT 1").fetchone()
        schedule = db.execute("SELECT id FROM schedules LIMIT 1").fetchone()
        db.close()

        # Login sebagai Dosen
        with self.client.session_transaction() as sess:
            sess['user_id'] = dosen['id']
            sess['name'] = 'Dr. Budi Santoso'
            sess['role'] = 'dosen'

        # Lakukan pengubahan jadwal via POST
        res = self.client.post(f"/schedule/{schedule['id']}/edit", data={
            'day': 'Jumat',
            'start_time': '14:00',
            'end_time': '16:30',
            'room': 'Lab Multimedia 1',
            'status': 'Jadwal Diubah / Rescheduled',
            'reason': 'Kelas pengganti minggu lalu',
            'notes': 'Wajib hadir tepat waktu'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Periksa apakah email masuk ke outbox
        db = get_db()
        outbox_entry = db.execute("""
            SELECT * FROM email_outbox 
            WHERE subject LIKE '%[Update Jadwal]%' 
            ORDER BY id DESC LIMIT 1
        """).fetchone()
        history_entry = db.execute("""
            SELECT * FROM schedule_history 
            WHERE schedule_id = ? 
            ORDER BY id DESC LIMIT 1
        """, (schedule['id'],)).fetchone()
        db.close()

        self.assertIsNotNone(outbox_entry, "Email notifikasi jadwal harus tercatat di outbox")
        self.assertIn("calendar.google.com", outbox_entry['gcal_link'])
        self.assertIsNotNone(history_entry, "Riwayat perubahan jadwal harus tersimpan")
        self.assertEqual(history_entry['new_day'], 'Jumat')

    def test_pj_remind_assignment(self):
        db = get_db()
        pj = db.execute("SELECT id FROM users WHERE role = 'pj' LIMIT 1").fetchone()
        assign = db.execute("SELECT id FROM assignments LIMIT 1").fetchone()
        db.close()

        with self.client.session_transaction() as sess:
            sess['user_id'] = pj['id']
            sess['name'] = 'Ahmad Rizki (PJ)'
            sess['role'] = 'pj'

        res = self.client.post(f"/assignment/{assign['id']}/remind", data={
            'custom_note': 'Tolong submit tugas sebelum malam minggu ya guys!'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        db = get_db()
        remind_email = db.execute("""
            SELECT * FROM email_outbox 
            WHERE subject LIKE '%[PENGINGAT TUGAS]%' 
            ORDER BY id DESC LIMIT 1
        """).fetchone()
        db.close()

        self.assertIsNotNone(remind_email, "Email pengingat dari PJ harus terkirim ke outbox")
        self.assertIn("Tolong submit tugas", remind_email['body_html'])

    def test_outbox_page_and_ics_download(self):
        # Test outbox view
        res = self.client.get('/outbox')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Log Pengiriman Email & Google Calendar", res.data)

        # Test download ics
        db = get_db()
        first_sched = db.execute("SELECT id FROM schedules LIMIT 1").fetchone()
        db.close()
        res = self.client.get(f'/download-ics/schedule/{first_sched["id"]}')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.headers.get('Content-Type'), 'text/calendar; charset=utf-8')
        self.assertIn(b"BEGIN:VCALENDAR", res.data)

    def test_admin_capabilities(self):
        # 1. Test Admin Login
        res = self.client.post('/login', data={
            'email': 'admin@um.ac.id',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Dashboard Administrator Akademik", res.data)

        # 2. Test Admin Tambah Pengguna Baru (Dosen)
        res_add_user = self.client.post('/admin/user/add', data={
            'name': 'Prof. Joko Widodo, M.T.',
            'identifier': '197001011995031001',
            'email': 'dosen.baru@um.ac.id',
            'role': 'dosen',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(res_add_user.status_code, 200)
        
        db = get_db()
        dosen_baru = db.execute("SELECT * FROM users WHERE email = 'dosen.baru@um.ac.id'").fetchone()
        self.assertIsNotNone(dosen_baru, "Dosen baru harus tersimpan di database")
        dosen_id = dosen_baru['id']

        # 3. Test Admin Tambah Mata Kuliah & Jadwal Baru
        res_add_course = self.client.post('/admin/course/add', data={
            'code': 'IF399',
            'name': 'Kapita Selekta Kecerdasan Buatan',
            'semester': 'Ganjil 2026/2027',
            'lecturer_id': str(dosen_id),
            'day': 'Selasa',
            'start_time': '13:00',
            'end_time': '15:30',
            'room': 'Lab AI Gedung C'
        }, follow_redirects=True)
        self.assertEqual(res_add_course.status_code, 200)

        course_baru = db.execute("SELECT * FROM courses WHERE code = 'IF399'").fetchone()
        self.assertIsNotNone(course_baru, "Mata kuliah baru harus tersimpan")
        
        schedule_baru = db.execute("SELECT * FROM schedules WHERE course_id = ?", (course_baru['id'],)).fetchone()
        self.assertIsNotNone(schedule_baru, "Jadwal untuk mata kuliah baru harus terbentuk")
        self.assertEqual(schedule_baru['room'], 'Lab AI Gedung C')
        db.close()

    def test_profile_and_change_password(self):
        # Login sebagai mahasiswa
        login_res = self.client.post('/login', data={
            'email': 'mhs1@mhs.kampus.ac.id',
            'password': 'password123'
        }, follow_redirects=True)
        self.assertEqual(login_res.status_code, 200)

        # 1. Buka halaman profil
        profile_res = self.client.get('/profile')
        self.assertEqual(profile_res.status_code, 200)
        self.assertIn(b"Profil Akun & Pengaturan Keamanan", profile_res.data)
        self.assertIn(b"mhs1@mhs.kampus.ac.id", profile_res.data)

        # 2. Ganti kata sandi dengan kata sandi lama yang salah
        err_res = self.client.post('/profile', data={
            'current_password': 'wrongpassword',
            'new_password': 'passwordbaru123',
            'confirm_password': 'passwordbaru123'
        }, follow_redirects=True)
        self.assertEqual(err_res.status_code, 200)
        self.assertIn(b"Kata sandi saat ini tidak cocok", err_res.data)

        # 3. Ganti kata sandi dengan benar
        success_res = self.client.post('/profile', data={
            'current_password': 'password123',
            'new_password': 'passwordbaru123',
            'confirm_password': 'passwordbaru123'
        }, follow_redirects=True)
        self.assertEqual(success_res.status_code, 200)
        self.assertIn(b"Kata sandi berhasil diperbarui", success_res.data)

        # 4. Logout dan coba login dengan password baru
        self.client.get('/logout')
        new_login_res = self.client.post('/login', data={
            'email': 'mhs1@mhs.kampus.ac.id',
            'password': 'passwordbaru123'
        }, follow_redirects=True)
        self.assertEqual(new_login_res.status_code, 200)
        self.assertIn(b"Dashboard Perkuliahan Mahasiswa", new_login_res.data)

        # Kembalikan password ke semula agar pengujian lain tetap konsisten
        self.client.post('/profile', data={
            'current_password': 'passwordbaru123',
            'new_password': 'password123',
            'confirm_password': 'password123'
        }, follow_redirects=True)

if __name__ == '__main__':
    unittest.main()
