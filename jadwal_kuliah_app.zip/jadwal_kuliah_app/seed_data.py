from database import get_db, init_db
from services.auth_service import hash_password
from datetime import datetime, timedelta

def seed():
    init_db()
    db = get_db()
    password_hash = hash_password("password123")

    # 1. Pastikan Pengguna Dasar Terdaftar
    users_data = [
        ("Admin Akademik UM", "admin@um.ac.id", "ADM001", "admin", password_hash),
        ("Dr. Budi Santoso, M.T.", "dosen1@kampus.ac.id", "198001012005011001", "dosen", password_hash),
        ("Siti Nurhaliza, M.Kom.", "dosen2@kampus.ac.id", "198502022008012002", "dosen", password_hash),
        ("Ahmad Rizki (PJ)", "pj.pemweb@mhs.kampus.ac.id", "220101001", "pj", password_hash),
        ("Dewi Lestari (PJ)", "pj.basdat@mhs.kampus.ac.id", "220101002", "pj", password_hash),
        ("Bambang Prakoso", "mhs1@mhs.kampus.ac.id", "220101010", "mahasiswa", password_hash),
        ("Putri Indah", "mhs2@mhs.kampus.ac.id", "220101011", "mahasiswa", password_hash),
        ("Rian Pratama", "mhs3@mhs.kampus.ac.id", "220101012", "mahasiswa", password_hash),
    ]

    for name, email, identifier, role, pwd in users_data:
        existing = db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        if not existing:
            db.execute("""
                INSERT INTO users (name, email, identifier, role, password_hash)
                VALUES (?, ?, ?, ?, ?)
            """, (name, email, identifier, role, pwd))
    db.commit()

    # Ambil ID Pengguna
    u_dosen1 = db.execute("SELECT id FROM users WHERE email = 'dosen1@kampus.ac.id'").fetchone()['id']
    u_dosen2 = db.execute("SELECT id FROM users WHERE email = 'dosen2@kampus.ac.id'").fetchone()['id']
    u_pj1 = db.execute("SELECT id FROM users WHERE email = 'pj.pemweb@mhs.kampus.ac.id'").fetchone()['id']
    u_pj2 = db.execute("SELECT id FROM users WHERE email = 'pj.basdat@mhs.kampus.ac.id'").fetchone()['id']
    u_mhs1 = db.execute("SELECT id FROM users WHERE email = 'mhs1@mhs.kampus.ac.id'").fetchone()['id']
    u_mhs2 = db.execute("SELECT id FROM users WHERE email = 'mhs2@mhs.kampus.ac.id'").fetchone()['id']
    u_mhs3 = db.execute("SELECT id FROM users WHERE email = 'mhs3@mhs.kampus.ac.id'").fetchone()['id']

    # 2. Pastikan Mata Kuliah Dasar Terdaftar
    courses_data = [
        ("IF301", "Pemrograman Web Lanjut", u_dosen1, u_pj1, "Ganjil 2026/2027"),
        ("IF302", "Basis Data Terdistribusi", u_dosen2, u_pj2, "Ganjil 2026/2027"),
        ("IF303", "Rekayasa Perangkat Lunak", u_dosen1, u_pj1, "Ganjil 2026/2027"),
    ]

    for code, name, doc_id, pj_id, sem in courses_data:
        existing_c = db.execute("SELECT id FROM courses WHERE code = ?", (code,)).fetchone()
        if not existing_c:
            db.execute("""
                INSERT INTO courses (code, name, lecturer_id, pj_id, semester)
                VALUES (?, ?, ?, ?, ?)
            """, (code, name, doc_id, pj_id, sem))
    db.commit()

    c1 = db.execute("SELECT id FROM courses WHERE code = 'IF301'").fetchone()['id']
    c2 = db.execute("SELECT id FROM courses WHERE code = 'IF302'").fetchone()['id']
    c3 = db.execute("SELECT id FROM courses WHERE code = 'IF303'").fetchone()['id']

    # 3. Pastikan Jadwal Awal Terdaftar
    schedules_data = [
        (c1, "Senin", "08:00", "10:30", "Lab Komputer 3", "Normal", "Harap bawa laptop dengan NodeJS & Python", u_dosen1),
        (c2, "Rabu", "10:00", "12:30", "Ruang Kuliah B.204", "Normal", "Modul praktikum sudah diupload di e-learning", u_dosen2),
        (c3, "Kamis", "13:00", "15:30", "Ruang Kuliah A.101", "Normal", "Presentasi progress kelompok bab 1-3", u_dosen1),
    ]

    for cid, day, st, et, room, status, notes, mod_by in schedules_data:
        existing_s = db.execute("SELECT id FROM schedules WHERE course_id = ?", (cid,)).fetchone()
        if not existing_s:
            db.execute("""
                INSERT INTO schedules (course_id, day, start_time, end_time, room, status, notes, last_modified_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (cid, day, st, et, room, status, notes, mod_by))
    db.commit()

    # 4. Pastikan Pendaftaran Mahasiswa (Enrollment) Terdaftar
    enroll_data = [
        (u_mhs1, c1),
        (u_mhs1, c2),
        (u_mhs1, c3),
        (u_mhs2, c1),
        (u_mhs2, c2),
        (u_mhs3, c1),
        (u_mhs3, c3),
    ]

    for uid, cid in enroll_data:
        db.execute("INSERT OR IGNORE INTO enrollments (user_id, course_id) VALUES (?, ?)", (uid, cid))
    db.commit()

    # 5. Pastikan Tugas Awal Terdaftar
    existing_assign = db.execute("SELECT COUNT(*) as c FROM assignments").fetchone()['c']
    if existing_assign == 0:
        d1 = (datetime.now() + timedelta(days=5)).strftime("%Y-%m-%d 23:59")
        d2 = (datetime.now() + timedelta(days=8)).strftime("%Y-%m-%d 23:59")
        
        assignments_data = [
            (c1, "Tugas 1: Integrasi Google Calendar & Autentikasi", "Implementasikan autentikasi user dan fitur export file kalender iCalendar RFC 5545.", d1, "Kirim via Google Classroom link", u_dosen1),
            (c2, "Tugas 1: Perancangan Schema Sharding Database", "Buat desain arsitektur distributed database beserta skema partisi horisontal.", d2, "Upload dokumen PDF di e-learning", u_dosen2)
        ]

        for cid, title, desc, dl, sub, creator in assignments_data:
            db.execute("""
                INSERT INTO assignments (course_id, title, description, deadline, submission_info, created_by)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (cid, title, desc, dl, sub, creator))
        db.commit()

    db.close()
    print("Database seeding verified & completed successfully!")

if __name__ == "__main__":
    seed()
