import urllib.parse
from datetime import datetime, timedelta, timezone
import uuid

INDONESIAN_DAYS = {
    'senin': 0,
    'selasa': 1,
    'rabu': 2,
    'kamis': 3,
    'jumat': 4,
    'sabtu': 5,
    'minggu': 6
}

def get_next_date_for_day(day_name, base_date=None):
    """
    Menghitung tanggal terdekat berikutnya untuk hari tertentu (misal: 'Senin').
    """
    if base_date is None:
        base_date = datetime.now()
    
    clean_day = day_name.lower().strip()
    target_weekday = INDONESIAN_DAYS.get(clean_day, 0)
    current_weekday = base_date.weekday()
    
    days_ahead = target_weekday - current_weekday
    if days_ahead <= 0: # jika hari ini atau sudah lewat di minggu ini, ambil minggu depan
        days_ahead += 7
        
    target_date = base_date + timedelta(days=days_ahead)
    return target_date

def parse_schedule_datetimes(day_name, start_time_str, end_time_str, specific_date=None):
    """
    Menghasilkan objek datetime (start_dt, end_dt) untuk jadwal perkuliahan.
    """
    if specific_date:
        if isinstance(specific_date, str):
            target_date = datetime.strptime(specific_date, "%Y-%m-%d")
        else:
            target_date = specific_date
    else:
        target_date = get_next_date_for_day(day_name)
    
    try:
        sh, sm = map(int, start_time_str.strip().split(':'))
        eh, em = map(int, end_time_str.strip().split(':'))
    except Exception:
        sh, sm = 8, 0
        eh, em = 10, 30
        
    start_dt = target_date.replace(hour=sh, minute=sm, second=0, microsecond=0)
    end_dt = target_date.replace(hour=eh, minute=em, second=0, microsecond=0)
    return start_dt, end_dt

def generate_gcal_link(title, description, location, start_dt, end_dt):
    """
    Membuat direct link penambahan event ke Google Calendar web:
    calendar.google.com/calendar/render?action=TEMPLATE&...
    """
    fmt = "%Y%m%dT%H%M%S"
    dates_str = f"{start_dt.strftime(fmt)}/{end_dt.strftime(fmt)}"
    
    params = {
        'action': 'TEMPLATE',
        'text': title,
        'dates': dates_str,
        'details': description,
        'location': location,
        'ctz': 'Asia/Jakarta'
    }
    
    base_url = "https://calendar.google.com/calendar/render"
    return f"{base_url}?{urllib.parse.urlencode(params)}"

def generate_ics_content(event_uid, title, description, location, start_dt, end_dt, sequence=0):
    """
    Membuat file format iCalendar RFC 5545 standar (.ics)
    Dengan METHOD:REQUEST sehingga Gmail otomatis mendeteksi dan memplot event.
    """
    fmt = "%Y%m%dT%H%M%S"
    dtstamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    
    # Escape special characters for iCalendar format
    def escape_ics(text):
        if not text:
            return ""
        return str(text).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    
    ics_lines = [
        "BEGIN:VCALENDAR",
        "PRODID:-//Portal Akademik Jadwal Perkuliahan//ID",
        "VERSION:2.0",
        "CALSCALE:GREGORIAN",
        "METHOD:REQUEST",
        "BEGIN:VEVENT",
        f"UID:{event_uid}@kampus.ac.id",
        f"DTSTAMP:{dtstamp}",
        f"DTSTART;TZID=Asia/Jakarta:{start_dt.strftime(fmt)}",
        f"DTEND;TZID=Asia/Jakarta:{end_dt.strftime(fmt)}",
        f"SUMMARY:{escape_ics(title)}",
        f"DESCRIPTION:{escape_ics(description)}",
        f"LOCATION:{escape_ics(location)}",
        "STATUS:CONFIRMED",
        f"SEQUENCE:{sequence}",
        "BEGIN:VALARM",
        "TRIGGER:-PT30M",
        "ACTION:DISPLAY",
        f"DESCRIPTION:Pengingat {escape_ics(title)}",
        "END:VALARM",
        "END:VEVENT",
        "END:VCALENDAR"
    ]
    
    return "\r\n".join(ics_lines)
