import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import os
import uuid

from config import Config
from database import get_db
from services.calendar_service import (
    parse_schedule_datetimes,
    generate_gcal_link,
    generate_ics_content
)

def send_or_queue_email(to_email, to_name, subject, html_content, gcal_link=None, ics_content=None, event_summary="", event_time=""):
    """
    Mengirim email melalui SMTP jika ENABLE_REAL_EMAIL=True,
    atau menyimpan simulasi ke database email_outbox.
    """
    status = "Tersimpan di Outbox (Simulasi)"
    
    if Config.ENABLE_REAL_EMAIL and Config.SMTP_USERNAME and Config.SMTP_PASSWORD:
        try:
            msg = MIMEMultipart("mixed")
            msg['From'] = f"{Config.SMTP_SENDER_NAME} <{Config.SMTP_SENDER_EMAIL}>"
            msg['To'] = f"{to_name} <{to_email}>"
            msg['Subject'] = subject

            # Body HTML
            msg_alt = MIMEMultipart("alternative")
            msg.attach(msg_alt)
            msg_alt.attach(MIMEText(html_content, "html", "utf-8"))

            # Attachment .ics
            if ics_content:
                part = MIMEBase("text", "calendar", method="REQUEST", name="undangan_jadwal.ics")
                part.set_payload(ics_content.encode("utf-8"))
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", 'attachment; filename="undangan_jadwal.ics"')
                part.add_header("Content-Class", "urn:content-classes:calendarmessage")
                msg.attach(part)

            with smtplib.SMTP(Config.SMTP_SERVER, Config.SMTP_PORT, timeout=10) as server:
                server.starttls()
                server.login(Config.SMTP_USERNAME, Config.SMTP_PASSWORD)
                server.send_message(msg)
                status = "Terkirim via SMTP"
        except Exception as e:
            status = f"Gagal SMTP ({str(e)[:40]}), Disimpan di Outbox"
    
    # Simpan riwayat ke email_outbox untuk transparansi di web portal
    db = get_db()
    db.execute("""
        INSERT INTO email_outbox (to_email, to_name, subject, body_html, gcal_link, event_summary, event_time, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (to_email, to_name, subject, html_content, gcal_link, event_summary, event_time, status))
    db.commit()
    db.close()
    return status

def build_schedule_email_html(student_name, course_code, course_name, old_info, new_info, changer_name, changer_role, reason, notes, gcal_link):
    role_label = "Dosen Pengampu" if changer_role == "dosen" else "PJ Mata Kuliah"
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; padding: 20px; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }}
            .header {{ background: linear-gradient(135deg, #1e40af, #3b82f6); color: #ffffff; padding: 28px 24px; text-align: center; }}
            .header h1 {{ margin: 0 0 8px; font-size: 22px; }}
            .header p {{ margin: 0; opacity: 0.9; font-size: 14px; }}
            .content {{ padding: 24px; }}
            .card-diff {{ background: #f1f5f9; border-radius: 8px; padding: 16px; margin: 16px 0; border-left: 4px solid #3b82f6; }}
            .old-val {{ color: #dc2626; text-decoration: line-through; font-weight: 500; }}
            .new-val {{ color: #16a34a; font-weight: bold; font-size: 16px; }}
            .info-table {{ width: 100%; border-collapse: collapse; margin-top: 12px; }}
            .info-table td {{ padding: 8px 4px; vertical-align: top; font-size: 14px; }}
            .btn-gcal {{ display: inline-block; background-color: #0284c7; color: #ffffff !important; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; font-size: 14px; margin-top: 20px; text-align: center; }}
            .btn-gcal:hover {{ background-color: #0369a1; }}
            .footer {{ background: #f8fafc; padding: 16px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Pemberitahuan Perubahan Jadwal Kuliah</h1>
                <p>{course_code} - {course_name}</p>
            </div>
            <div class="content">
                <p>Halo <strong>{student_name}</strong>,</p>
                <p>Terdapat perubahan jadwal perkuliahan yang telah diperbarui oleh <strong>{changer_name}</strong> ({role_label}):</p>
                
                <div class="card-diff">
                    <table class="info-table">
                        <tr>
                            <td width="35%"><strong>Mata Kuliah:</strong></td>
                            <td>{course_code} - {course_name}</td>
                        </tr>
                        <tr>
                            <td><strong>Jadwal Sebelumnya:</strong></td>
                            <td class="old-val">{old_info}</td>
                        </tr>
                        <tr>
                            <td><strong>Jadwal Baru:</strong></td>
                            <td class="new-val">{new_info}</td>
                        </tr>
                        {f'<tr><td><strong>Alasan:</strong></td><td>{reason}</td></tr>' if reason else ''}
                        {f'<tr><td><strong>Catatan:</strong></td><td>{notes}</td></tr>' if notes else ''}
                    </table>
                </div>

                <p style="font-size: 14px; line-height: 1.5;">
                    Perubahan jadwal ini juga telah disinkronkan. Anda dapat langsung menyimpan jadwal baru ini ke Google Calendar Anda dalam satu klik:
                </p>

                <div style="text-align: center; margin: 24px 0;">
                    <a href="{gcal_link}" target="_blank" class="btn-gcal">
                        📅 Simpan ke Google Calendar Saya
                    </a>
                </div>

                <p style="font-size: 13px; color: #64748b;">
                    <em>Catatan: Email ini juga melampirkan file undangan kalender (<code>.ics</code>). Jika email Anda terhubung dengan Google Calendar, event ini akan otomatis terplot.</em>
                </p>
            </div>
            <div class="footer">
                Sistem Portal Perkuliahan &middot; Notifikasi Otomatis Terintegrasi Google Calendar
            </div>
        </div>
    </body>
    </html>
    """

def build_assignment_email_html(student_name, course_code, course_name, assignment_title, description, deadline_str, submission_info, gcal_link, is_reminder=False, custom_note=None, sender_name=None):
    headline = "Pengingat Tenggat Tugas Perkuliahan" if is_reminder else "Pemberitahuan Tugas Baru"
    header_color = "linear-gradient(135deg, #d97706, #f59e0b)" if is_reminder else "linear-gradient(135deg, #059669, #10b981)"
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; padding: 20px; }}
            .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }}
            .header {{ background: {header_color}; color: #ffffff; padding: 28px 24px; text-align: center; }}
            .header h1 {{ margin: 0 0 8px; font-size: 22px; }}
            .header p {{ margin: 0; opacity: 0.9; font-size: 14px; }}
            .content {{ padding: 24px; }}
            .task-box {{ background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 18px; margin: 16px 0; }}
            .deadline-badge {{ display: inline-block; background: #ef4444; color: #ffffff; padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 13px; }}
            .btn-gcal {{ display: inline-block; background-color: #059669; color: #ffffff !important; text-decoration: none; padding: 12px 24px; border-radius: 8px; font-weight: 600; font-size: 14px; margin-top: 15px; text-align: center; }}
            .btn-gcal:hover {{ background-color: #047857; }}
            .footer {{ background: #f8fafc; padding: 16px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{headline}</h1>
                <p>{course_code} - {course_name}</p>
            </div>
            <div class="content">
                <p>Halo <strong>{student_name}</strong>,</p>
                <p>{f'Pengingat dari PJ Matkul <strong>{sender_name}</strong> untuk tugas berikut:' if is_reminder else 'Dosen pengampu telah mengunggah tugas perkuliahan baru:'}</p>
                
                <div class="task-box">
                    <h3 style="margin-top: 0; color: #b45309; font-size: 18px;">{assignment_title}</h3>
                    <p style="margin: 8px 0; font-size: 14px; line-height: 1.5;">{description}</p>
                    <hr style="border: none; border-top: 1px dashed #fcd34d; margin: 12px 0;">
                    <p style="margin: 6px 0; font-size: 14px;"><strong>Tenggat Waktu:</strong> <span class="deadline-badge">{deadline_str} WIB</span></p>
                    {f'<p style="margin: 6px 0; font-size: 14px;"><strong>Petunjuk Pengumpulan:</strong> {submission_info}</p>' if submission_info else ''}
                    {f'<div style="background: #fef3c7; padding: 10px; border-radius: 6px; margin-top: 10px; font-size: 13px; color: #92400e;"><strong>Pesan Pengingat:</strong> "{custom_note}"</div>' if custom_note else ''}
                </div>

                <p style="font-size: 14px; line-height: 1.5;">
                    Jangan sampai terlewat! Masukkan batas waktu tugas ini langsung ke Google Calendar Anda:
                </p>

                <div style="text-align: center; margin: 20px 0;">
                    <a href="{gcal_link}" target="_blank" class="btn-gcal">
                        ⏰ Pasang Pengingat di Google Calendar
                    </a>
                </div>
            </div>
            <div class="footer">
                Sistem Portal Perkuliahan &middot; Notifikasi Otomatis Terintegrasi Google Calendar
            </div>
        </div>
    </body>
    </html>
    """

def notify_schedule_change(schedule_id, changer_user_id, reason=""):
    """
    Kirim email notifikasi perubahan jadwal ke semua mahasiswa peserta matkul.
    """
    db = get_db()
    
    # Ambil data jadwal & matkul
    schedule = db.execute("""
        SELECT s.*, c.code AS course_code, c.name AS course_name
        FROM schedules s
        JOIN courses c ON s.course_id = c.id
        WHERE s.id = ?
    """, (schedule_id,)).fetchone()
    
    if not schedule:
        db.close()
        return 0

    # Ambil pengubah
    changer = db.execute("SELECT name, role FROM users WHERE id = ?", (changer_user_id,)).fetchone()
    changer_name = changer['name'] if changer else "Admin Perkuliahan"
    changer_role = changer['role'] if changer else "dosen"

    # Ambil riwayat terakhir untuk melihat jadwal lama
    history = db.execute("""
        SELECT * FROM schedule_history 
        WHERE schedule_id = ? 
        ORDER BY id DESC LIMIT 1
    """, (schedule_id,)).fetchone()

    old_info = f"{history['old_day']}, {history['old_time']} (Ruang {history['old_room']})" if history else "Jadwal sebelumnya"
    new_info = f"{schedule['day']}, {schedule['start_time']} - {schedule['end_time']} ({schedule['room']}) - Status: {schedule['status']}"

    # Generate dates & links
    start_dt, end_dt = parse_schedule_datetimes(schedule['day'], schedule['start_time'], schedule['end_time'])
    title = f"Kuliah: {schedule['course_code']} - {schedule['course_name']} ({schedule['status']})"
    description = f"Perubahan Jadwal oleh {changer_name} ({changer_role}).\nAlasan: {reason}\nCatatan: {schedule['notes']}"
    location = schedule['room']
    
    gcal_link = generate_gcal_link(title, description, location, start_dt, end_dt)
    event_uid = f"sch-{schedule['id']}-{int(datetime.now().timestamp())}"
    ics_content = generate_ics_content(event_uid, title, description, location, start_dt, end_dt)

    # Ambil seluruh mahasiswa yang terdaftar di matkul ini
    students = db.execute("""
        SELECT u.id, u.name, u.email 
        FROM users u
        JOIN enrollments e ON u.id = e.user_id
        WHERE e.course_id = ? AND u.role = 'mahasiswa'
    """, (schedule['course_id'],)).fetchall()
    
    sent_count = 0
    for s in students:
        html = build_schedule_email_html(
            student_name=s['name'],
            course_code=schedule['course_code'],
            course_name=schedule['course_name'],
            old_info=old_info,
            new_info=new_info,
            changer_name=changer_name,
            changer_role=changer_role,
            reason=reason,
            notes=schedule['notes'],
            gcal_link=gcal_link
        )
        subject = f"[Update Jadwal] {schedule['course_code']} {schedule['course_name']} -> {schedule['day']} {schedule['start_time']}"
        send_or_queue_email(
            to_email=s['email'],
            to_name=s['name'],
            subject=subject,
            html_content=html,
            gcal_link=gcal_link,
            ics_content=ics_content,
            event_summary=title,
            event_time=f"{schedule['day']}, {schedule['start_time']} - {schedule['end_time']}"
        )
        sent_count += 1

    db.close()
    return sent_count

def notify_new_assignment(assignment_id, creator_user_id):
    """
    Kirim email notifikasi tugas baru ke semua mahasiswa peserta matkul.
    """
    db = get_db()
    assign = db.execute("""
        SELECT a.*, c.code AS course_code, c.name AS course_name, u.name AS creator_name
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        LEFT JOIN users u ON a.created_by = u.id
        WHERE a.id = ?
    """, (assignment_id,)).fetchone()

    if not assign:
        db.close()
        return 0

    try:
        deadline_dt = datetime.strptime(assign['deadline'], "%Y-%m-%d %H:%M")
    except Exception:
        deadline_dt = datetime.now()

    # Buat event kalender di Google Calendar: 1 jam sebelum deadline
    start_dt = deadline_dt
    end_dt = deadline_dt
    title = f"TENGGAT TUGAS: {assign['course_code']} - {assign['title']}"
    description = f"Deskripsi: {assign['description']}\nPetunjuk: {assign['submission_info']}"
    location = "Portal Kampus"
    gcal_link = generate_gcal_link(title, description, location, start_dt, end_dt)
    event_uid = f"task-{assign['id']}-{int(datetime.now().timestamp())}"
    ics_content = generate_ics_content(event_uid, title, description, location, start_dt, end_dt)

    students = db.execute("""
        SELECT u.id, u.name, u.email 
        FROM users u
        JOIN enrollments e ON u.id = e.user_id
        WHERE e.course_id = ? AND u.role = 'mahasiswa'
    """, (assign['course_id'],)).fetchall()

    sent_count = 0
    for s in students:
        html = build_assignment_email_html(
            student_name=s['name'],
            course_code=assign['course_code'],
            course_name=assign['course_name'],
            assignment_title=assign['title'],
            description=assign['description'],
            deadline_str=assign['deadline'],
            submission_info=assign['submission_info'],
            gcal_link=gcal_link,
            is_reminder=False,
            sender_name=assign['creator_name']
        )
        subject = f"[Tugas Baru] {assign['course_code']} - {assign['title']} (Deadline: {assign['deadline']})"
        send_or_queue_email(
            to_email=s['email'],
            to_name=s['name'],
            subject=subject,
            html_content=html,
            gcal_link=gcal_link,
            ics_content=ics_content,
            event_summary=title,
            event_time=assign['deadline']
        )
        sent_count += 1

    db.close()
    return sent_count

def notify_assignment_reminder(assignment_id, reminder_user_id, custom_note=""):
    """
    Kirim email pengingat tugas dari PJ Matkul ke semua mahasiswa peserta matkul.
    """
    db = get_db()
    assign = db.execute("""
        SELECT a.*, c.code AS course_code, c.name AS course_name
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    """, (assignment_id,)).fetchone()

    if not assign:
        db.close()
        return 0

    reminder_user = db.execute("SELECT name FROM users WHERE id = ?", (reminder_user_id,)).fetchone()
    sender_name = reminder_user['name'] if reminder_user else "PJ Mata Kuliah"

    # Simpan riwayat reminder
    db.execute("""
        INSERT INTO assignment_reminders (assignment_id, reminded_by, custom_message)
        VALUES (?, ?, ?)
    """, (assignment_id, reminder_user_id, custom_note))
    db.commit()

    try:
        deadline_dt = datetime.strptime(assign['deadline'], "%Y-%m-%d %H:%M")
    except Exception:
        deadline_dt = datetime.now()

    title = f"PENGINGAT TUGAS: {assign['course_code']} - {assign['title']}"
    description = f"Pengingat dari PJ Matkul ({sender_name}):\n{custom_note}\n\nTenggat: {assign['deadline']}\nPetunjuk: {assign['submission_info']}"
    location = "Portal Kampus"
    gcal_link = generate_gcal_link(title, description, location, deadline_dt, deadline_dt)
    event_uid = f"remind-{assign['id']}-{int(datetime.now().timestamp())}"
    ics_content = generate_ics_content(event_uid, title, description, location, deadline_dt, deadline_dt)

    students = db.execute("""
        SELECT u.id, u.name, u.email 
        FROM users u
        JOIN enrollments e ON u.id = e.user_id
        WHERE e.course_id = ? AND u.role = 'mahasiswa'
    """, (assign['course_id'],)).fetchall()

    sent_count = 0
    for s in students:
        html = build_assignment_email_html(
            student_name=s['name'],
            course_code=assign['course_code'],
            course_name=assign['course_name'],
            assignment_title=assign['title'],
            description=assign['description'],
            deadline_str=assign['deadline'],
            submission_info=assign['submission_info'],
            gcal_link=gcal_link,
            is_reminder=True,
            custom_note=custom_note,
            sender_name=sender_name
        )
        subject = f"[PENGINGAT TUGAS] {assign['course_code']} - {assign['title']} (Tenggat: {assign['deadline']})"
        send_or_queue_email(
            to_email=s['email'],
            to_name=s['name'],
            subject=subject,
            html_content=html,
            gcal_link=gcal_link,
            ics_content=ics_content,
            event_summary=title,
            event_time=assign['deadline']
        )
        sent_count += 1

    db.close()
    return sent_count
