import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "fallback-secret-key-development")
    DATABASE_PATH = os.path.join(os.path.dirname(__file__), "kampus.db")
    
    ENABLE_REAL_EMAIL = os.getenv("ENABLE_REAL_EMAIL", "false").lower() in ("true", "1", "yes")
    SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
    SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_SENDER_EMAIL = os.getenv("SMTP_SENDER_EMAIL", "portal.kuliah@kampus.ac.id")
    SMTP_SENDER_NAME = os.getenv("SMTP_SENDER_NAME", "Portal Akademik Jadwal & Tugas")
    
    APP_BASE_URL = os.getenv("APP_BASE_URL", "http://localhost:5000")
