import os
from datetime import datetime
from flask import (
    Flask, render_template, request, redirect, url_for, flash, session, Response
)

from config import Config
from database import get_db, init_db
from seed_data import seed
from services.auth_service import (
    hash_password, verify_password, login_required, role_required
)
from services.calendar_service import (
    parse_schedule_datetimes,
    generate_gcal_link,
    generate_ics_content
)
from services.email_service import (
    notify_schedule_change,
    notify_new_assignment,
    notify_assignment_reminder
)
import models

app = Flask(__name__)
app.config.from_object(Config)

# Inisialisasi dan seed database saat start
with app.app_context():
    init_db()
    seed()

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        db.close()

        if user and verify_password(user['password_hash'], password):
            session['user_id'] = user['id']
            session['name'] = user['name']
            session['email'] = user['email']
            session['identifier'] = user['identifier']
            session['role'] = user['role']
            flash(f"Selamat datang kembali, {user['name']}!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Email atau kata sandi tidak valid. Silakan coba lagi.", "danger")

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        identifier = request.form.get('identifier', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()

        if not name or not identifier or not email or not password:
            flash("Semua field pendaftaran wajib diisi.", "danger")
            return render_template('register.html')

        db = get_db()
        existing = db.execute(
            "SELECT id FROM users WHERE email = ? OR identifier = ?", (email, identifier)
        ).fetchone()

        if existing:
            db.close()
            flash("Email atau NIM sudah terdaftar. Silakan gunakan email lain atau langsung login.", "warning")
            return render_template('register.html')

        pwd_hash = hash_password(password)
        cursor = db.cursor()
        cursor.execute("""
            INSERT INTO users (name, email, identifier, role, password_hash)
            VALUES (?, ?, ?, 'mahasiswa', ?)
        """, (name, email, identifier, pwd_hash))
        new_id = cursor.lastrowid

        # Otomatis enroll ke matkul default agar mahasiswa langsung memiliki jadwal
        default_courses = db.execute("SELECT id FROM courses LIMIT 2").fetchall()
        for dc in default_courses:
            db.execute("INSERT OR IGNORE INTO enrollments (user_id, course_id) VALUES (?, ?)", (new_id, dc['id']))

        db.commit()
        db.close()

        session['user_id'] = new_id
        session['name'] = name
        session['email'] = email
        session['identifier'] = identifier
        session['role'] = 'mahasiswa'

        flash("Registrasi berhasil! Anda telah otomatis didaftarkan pada mata kuliah dasar.", "success")
        return redirect(url_for('dashboard'))

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Anda telah berhasil keluar dari akun.", "info")
    return redirect(url_for('login'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user_id = session.get('user_id')
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    
    if not user:
        db.close()
        session.clear()
        flash("Sesi pengguna tidak valid. Silakan login kembali.", "warning")
        return redirect(url_for('login'))

    if request.method == 'POST':
        current_password = request.form.get('current_password', '').strip()
        new_password = request.form.get('new_password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()

        if not current_password or not new_password or not confirm_password:
            flash("Semua kolom kata sandi wajib diisi.", "danger")
            db.close()
            return redirect(url_for('profile'))

        if not verify_password(user['password_hash'], current_password):
            flash("Kata sandi saat ini tidak cocok.", "danger")
            db.close()
            return redirect(url_for('profile'))

        if len(new_password) < 6:
            flash("Kata sandi baru minimal 6 karakter.", "warning")
            db.close()
            return redirect(url_for('profile'))

        if new_password != confirm_password:
            flash("Konfirmasi kata sandi baru tidak cocok.", "danger")
            db.close()
            return redirect(url_for('profile'))

        new_hash = hash_password(new_password)
        db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (new_hash, user_id))
        db.commit()
        db.close()

        flash("Kata sandi berhasil diperbarui. Silakan gunakan kata sandi baru untuk login berikutnya.", "success")
        return redirect(url_for('profile'))

    # Data tambahan berdasarkan peran
    extra_data = {}
    role = user['role']
    if role == 'dosen':
        extra_data['courses'] = db.execute("""
            SELECT c.*, s.day, s.start_time, s.end_time, s.room
            FROM courses c
            LEFT JOIN schedules s ON c.id = s.course_id
            WHERE c.lecturer_id = ?
            ORDER BY c.code ASC
        """, (user_id,)).fetchall()
    elif role == 'pj':
        extra_data['courses'] = db.execute("""
            SELECT c.*, s.day, s.start_time, s.end_time, s.room
            FROM courses c
            LEFT JOIN schedules s ON c.id = s.course_id
            WHERE c.pj_id = ?
            ORDER BY c.code ASC
        """, (user_id,)).fetchall()
    elif role == 'mahasiswa':
        extra_data['courses'] = db.execute("""
            SELECT c.*, s.day, s.start_time, s.end_time, s.room
            FROM courses c
            JOIN enrollments e ON c.id = e.course_id
            LEFT JOIN schedules s ON c.id = s.course_id
            WHERE e.user_id = ?
            ORDER BY s.day ASC, s.start_time ASC
        """, (user_id,)).fetchall()
    elif role == 'admin':
        extra_data['stats'] = models.get_admin_overview()

    db.close()
    return render_template('profile.html', user=user, extra_data=extra_data)

@app.route('/dashboard')
@login_required
def dashboard():
    role = session.get('role')
    if role == 'admin':
        return redirect(url_for('dashboard_admin'))
    elif role == 'dosen':
        return redirect(url_for('dashboard_dosen'))
    elif role == 'pj':
        return redirect(url_for('dashboard_pj'))
    else:
        return redirect(url_for('dashboard_mahasiswa'))

@app.route('/admin/dashboard')
@login_required
@role_required('admin')
def dashboard_admin():
    stats = models.get_admin_overview()
    courses = models.get_all_courses_with_details()
    users = models.get_all_users_list()
    lecturers = models.get_lecturers_list()
    pjs = models.get_pjs_list()
    return render_template(
        'dashboard_admin.html',
        stats=stats,
        courses=courses,
        users=users,
        lecturers=lecturers,
        pjs=pjs
    )

@app.route('/admin/course/add', methods=['POST'])
@login_required
@role_required('admin')
def admin_add_course():
    admin_id = session.get('user_id')
    code = request.form.get('code', '').strip().upper()
    name = request.form.get('name', '').strip()
    lecturer_id = request.form.get('lecturer_id') or None
    pj_id = request.form.get('pj_id') or None
    semester = request.form.get('semester', 'Ganjil 2026/2027').strip()
    day = request.form.get('day', 'Senin')
    start_time = request.form.get('start_time', '08:00')
    end_time = request.form.get('end_time', '10:30')
    room = request.form.get('room', 'Ruang Kelas').strip()

    if not code or not name:
        flash("Kode dan nama mata kuliah wajib diisi.", "danger")
        return redirect(url_for('dashboard_admin'))

    db = get_db()
    existing = db.execute("SELECT id FROM courses WHERE code = ?", (code,)).fetchone()
    db.close()
    if existing:
        flash(f"Mata kuliah dengan kode {code} sudah terdaftar.", "warning")
        return redirect(url_for('dashboard_admin'))

    models.create_course_with_schedule(
        code, name, lecturer_id, pj_id, semester, day, start_time, end_time, room, admin_id
    )
    flash(f"Mata kuliah {code} - {name} dan jadwal perdananya berhasil ditambahkan.", "success")
    return redirect(url_for('dashboard_admin'))

@app.route('/admin/course/<int:course_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def admin_delete_course(course_id):
    models.delete_course(course_id)
    flash("Mata kuliah berhasil dihapus dari sistem.", "info")
    return redirect(url_for('dashboard_admin'))

@app.route('/admin/user/add', methods=['POST'])
@login_required
@role_required('admin')
def admin_add_user():
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    identifier = request.form.get('identifier', '').strip()
    role = request.form.get('role', 'mahasiswa')
    password = request.form.get('password', 'password123').strip()

    if not name or not email or not identifier or not role:
        flash("Semua informasi pengguna wajib diisi.", "danger")
        return redirect(url_for('dashboard_admin'))

    db = get_db()
    existing = db.execute(
        "SELECT id FROM users WHERE email = ? OR identifier = ?", (email, identifier)
    ).fetchone()
    db.close()

    if existing:
        flash("Email atau NIP/NIM sudah terdaftar untuk pengguna lain.", "warning")
        return redirect(url_for('dashboard_admin'))

    pwd_hash = hash_password(password)
    models.create_user(name, email, identifier, role, pwd_hash)
    flash(f"Pengguna baru ({name} - {role.upper()}) berhasil didaftarkan.", "success")
    return redirect(url_for('dashboard_admin'))

@app.route('/admin/user/<int:user_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def admin_delete_user(user_id):
    if user_id == session.get('user_id'):
        flash("Anda tidak dapat menghapus akun Anda sendiri.", "danger")
        return redirect(url_for('dashboard_admin'))

    models.delete_user(user_id)
    flash("Pengguna berhasil dihapus.", "info")
    return redirect(url_for('dashboard_admin'))

@app.route('/dosen/dashboard')
@login_required
@role_required('dosen')
def dashboard_dosen():
    user_id = session.get('user_id')
    courses = models.get_courses_for_lecturer(user_id)
    return render_template('dashboard_dosen.html', courses=courses)

@app.route('/pj/dashboard')
@login_required
@role_required('pj')
def dashboard_pj():
    user_id = session.get('user_id')
    courses = models.get_courses_for_pj(user_id)
    
    # Ambil tugas dari semua matkul yang di-PJ-kan
    db = get_db()
    course_ids = [c['id'] for c in courses]
    assignments = []
    if course_ids:
        placeholders = ','.join('?' for _ in course_ids)
        assignments = db.execute(f"""
            SELECT a.*, c.code AS course_code, c.name AS course_name
            FROM assignments a
            JOIN courses c ON a.course_id = c.id
            WHERE a.course_id IN ({placeholders})
            ORDER BY a.deadline ASC
        """, course_ids).fetchall()
    db.close()

    return render_template('dashboard_pj.html', courses=courses, assignments=assignments)

@app.route('/mahasiswa/dashboard')
@login_required
@role_required('mahasiswa')
def dashboard_mahasiswa():
    user_id = session.get('user_id')
    enrolled_courses, all_courses, assignments, recent_changes = models.get_student_dashboard_data(user_id)
    return render_template(
        'dashboard_mhs.html',
        enrolled_courses=enrolled_courses,
        all_courses=all_courses,
        assignments=assignments,
        recent_changes=recent_changes
    )

@app.route('/course/<int:course_id>')
@login_required
def course_detail(course_id):
    course, assignments, students, history = models.get_course_detail(course_id)
    if not course:
        flash("Mata kuliah tidak ditemukan.", "danger")
        return redirect(url_for('dashboard'))
    return render_template(
        'course_detail.html',
        course=course,
        assignments=assignments,
        students=students,
        history=history
    )

@app.route('/schedule/<int:schedule_id>/edit', methods=['POST'])
@login_required
@role_required('admin', 'dosen', 'pj')
def edit_schedule(schedule_id):
    user_id = session.get('user_id')
    user_name = session.get('name')
    user_role = session.get('role')

    day = request.form.get('day')
    start_time = request.form.get('start_time')
    end_time = request.form.get('end_time')
    room = request.form.get('room')
    status = request.form.get('status', 'Jadwal Diubah / Rescheduled')
    notes = request.form.get('notes', '')
    reason = request.form.get('reason', '')

    db = get_db()
    current_schedule = db.execute("SELECT * FROM schedules WHERE id = ?", (schedule_id,)).fetchone()
    if not current_schedule:
        db.close()
        flash("Jadwal tidak ditemukan.", "danger")
        return redirect(url_for('dashboard'))

    # Rekam riwayat perubahan
    db.execute("""
        INSERT INTO schedule_history (
            schedule_id, course_id, old_day, old_time, old_room, old_status,
            new_day, new_time, new_room, new_status, reason, changed_by_name, changed_by_role
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        schedule_id,
        current_schedule['course_id'],
        current_schedule['day'],
        f"{current_schedule['start_time']} - {current_schedule['end_time']}",
        current_schedule['room'],
        current_schedule['status'],
        day,
        f"{start_time} - {end_time}",
        room,
        status,
        reason,
        user_name,
        user_role
    ))

    # Perbarui jadwal aktif
    db.execute("""
        UPDATE schedules
        SET day = ?, start_time = ?, end_time = ?, room = ?, status = ?, notes = ?, last_modified_by = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (day, start_time, end_time, room, status, notes, user_id, schedule_id))
    db.commit()
    db.close()

    # Kirim blast email notifikasi dan sinkronisasi kalender ke semua mahasiswa terdaftar
    sent_count = notify_schedule_change(schedule_id, user_id, reason)

    flash(
        f"Jadwal berhasil diperbarui. Notifikasi email & link Google Calendar dikirim ke {sent_count} mahasiswa terdaftar.",
        "success"
    )
    return redirect(request.referrer or url_for('dashboard'))

@app.route('/assignment/add', methods=['POST'])
@login_required
@role_required('dosen')
def add_assignment():
    user_id = session.get('user_id')
    course_id = request.form.get('course_id')
    title = request.form.get('title')
    deadline = request.form.get('deadline')
    description = request.form.get('description')
    submission_info = request.form.get('submission_info', '')

    # Format deadline ISO 'YYYY-MM-DDTHH:MM' -> 'YYYY-MM-DD HH:MM'
    if 'T' in deadline:
        deadline = deadline.replace('T', ' ')

    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        INSERT INTO assignments (course_id, title, description, deadline, submission_info, created_by)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (course_id, title, description, deadline, submission_info, user_id))
    new_assign_id = cursor.lastrowid
    db.commit()
    db.close()

    # Kirim notifikasi email tugas baru
    sent_count = notify_new_assignment(new_assign_id, user_id)

    flash(
        f"Tugas baru berhasil dibuat. Email pemberitahuan & pengingat Google Calendar dikirim ke {sent_count} mahasiswa.",
        "success"
    )
    return redirect(url_for('dashboard_dosen'))

@app.route('/assignment/<int:assignment_id>/remind', methods=['POST'])
@login_required
@role_required('pj')
def remind_assignment(assignment_id):
    user_id = session.get('user_id')
    custom_note = request.form.get('custom_note', '')

    sent_count = notify_assignment_reminder(assignment_id, user_id, custom_note)

    flash(
        f"Pengingat tugas berhasil dikirimkan ke {sent_count} mahasiswa via email & kalender.",
        "success"
    )
    return redirect(url_for('dashboard_pj'))

@app.route('/courses/<int:course_id>/enroll', methods=['POST'])
@login_required
@role_required('mahasiswa')
def enroll_course(course_id):
    user_id = session.get('user_id')
    db = get_db()
    db.execute("INSERT OR IGNORE INTO enrollments (user_id, course_id) VALUES (?, ?)", (user_id, course_id))
    db.commit()
    db.close()
    flash("Berhasil mengambil mata kuliah. Anda akan menerima notifikasi jika jadwal berubah.", "success")
    return redirect(url_for('dashboard_mahasiswa'))

@app.route('/courses/<int:course_id>/unenroll', methods=['POST'])
@login_required
@role_required('mahasiswa')
def unenroll_course(course_id):
    user_id = session.get('user_id')
    db = get_db()
    db.execute("DELETE FROM enrollments WHERE user_id = ? AND course_id = ?", (user_id, course_id))
    db.commit()
    db.close()
    flash("Mata kuliah berhasil dibatalkan dari daftar Anda.", "info")
    return redirect(url_for('dashboard_mahasiswa'))

@app.route('/sync/schedule/<int:schedule_id>/gcal')
def sync_schedule_gcal(schedule_id):
    db = get_db()
    schedule = db.execute("""
        SELECT s.*, c.code AS course_code, c.name AS course_name
        FROM schedules s
        JOIN courses c ON s.course_id = c.id
        WHERE s.id = ?
    """, (schedule_id,)).fetchone()
    db.close()

    if not schedule:
        flash("Jadwal tidak ditemukan.", "danger")
        return redirect(url_for('dashboard'))

    start_dt, end_dt = parse_schedule_datetimes(schedule['day'], schedule['start_time'], schedule['end_time'])
    title = f"Kuliah: {schedule['course_code']} - {schedule['course_name']}"
    desc = f"Status: {schedule['status']}\nCatatan: {schedule['notes']}"
    loc = schedule['room']

    url = generate_gcal_link(title, desc, loc, start_dt, end_dt)
    return redirect(url)

@app.route('/sync/assignment/<int:assignment_id>/gcal')
def sync_assignment_gcal(assignment_id):
    db = get_db()
    assign = db.execute("""
        SELECT a.*, c.code AS course_code, c.name AS course_name
        FROM assignments a
        JOIN courses c ON a.course_id = c.id
        WHERE a.id = ?
    """, (assignment_id,)).fetchone()
    db.close()

    if not assign:
        flash("Tugas tidak ditemukan.", "danger")
        return redirect(url_for('dashboard'))

    try:
        deadline_dt = datetime.strptime(assign['deadline'], "%Y-%m-%d %H:%M")
    except Exception:
        deadline_dt = datetime.now()

    title = f"TENGGAT TUGAS: {assign['course_code']} - {assign['title']}"
    desc = f"Deskripsi: {assign['description']}\nPetunjuk: {assign['submission_info']}"
    loc = "Portal Kampus"

    url = generate_gcal_link(title, desc, loc, deadline_dt, deadline_dt)
    return redirect(url)

@app.route('/download-ics/<item_type>/<int:item_id>')
def download_ics(item_type, item_id):
    db = get_db()
    if item_type == 'schedule':
        item = db.execute("""
            SELECT s.*, c.code AS course_code, c.name AS course_name
            FROM schedules s
            JOIN courses c ON s.course_id = c.id
            WHERE s.id = ?
        """, (item_id,)).fetchone()
        db.close()
        if not item:
            return "Item not found", 404
        start_dt, end_dt = parse_schedule_datetimes(item['day'], item['start_time'], item['end_time'])
        title = f"Kuliah: {item['course_code']} - {item['course_name']}"
        desc = f"Status: {item['status']}\nCatatan: {item['notes']}"
        loc = item['room']
        uid = f"sch-{item['id']}"
    else:
        item = db.execute("""
            SELECT a.*, c.code AS course_code, c.name AS course_name
            FROM assignments a
            JOIN courses c ON a.course_id = c.id
            WHERE a.id = ?
        """, (item_id,)).fetchone()
        db.close()
        if not item:
            return "Item not found", 404
        try:
            start_dt = datetime.strptime(item['deadline'], "%Y-%m-%d %H:%M")
        except Exception:
            start_dt = datetime.now()
        end_dt = start_dt
        title = f"Tenggat Tugas: {item['course_code']} - {item['title']}"
        desc = f"Deskripsi: {item['description']}\nPetunjuk: {item['submission_info']}"
        loc = "Portal Kampus"
        uid = f"task-{item['id']}"

    ics_data = generate_ics_content(uid, title, desc, loc, start_dt, end_dt)
    filename = f"{uid}.ics"

    return Response(
        ics_data,
        mimetype="text/calendar",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@app.route('/outbox')
def view_outbox():
    db = get_db()
    logs = db.execute("SELECT * FROM email_outbox ORDER BY id DESC").fetchall()
    db.close()
    return render_template('outbox.html', logs=logs, config_real_email=Config.ENABLE_REAL_EMAIL)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
