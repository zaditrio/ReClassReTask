document.addEventListener('DOMContentLoaded', () => {
    // 1. Modal Dialog Logic
    const modals = document.querySelectorAll('.modal-overlay');
    
    // Close modal on click outside or close button
    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.classList.contains('modal-close') || e.target.closest('.modal-close')) {
                closeModal(modal.id);
            }
        });
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            modals.forEach(m => m.classList.remove('active'));
        }
    });

    // 2. Countdown Calculation for Deadlines
    const countdownElements = document.querySelectorAll('[data-deadline]');
    countdownElements.forEach(el => {
        const deadlineStr = el.getAttribute('data-deadline');
        if (!deadlineStr) return;

        const deadlineDate = new Date(deadlineStr.replace(' ', 'T'));
        const now = new Date();
        const diffMs = deadlineDate - now;

        if (diffMs <= 0) {
            el.innerHTML = '<span style="color: #dc2626; font-weight: bold;">Telah Berakhir</span>';
        } else {
            const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
            const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            
            if (diffDays > 0) {
                el.innerHTML = `<span style="color: #d97706; font-weight: 600;">Tersisa ${diffDays} hari ${diffHours} jam</span>`;
            } else {
                const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                el.innerHTML = `<span style="color: #ef4444; font-weight: bold;">Mendekati batas: ${diffHours} jam ${diffMins} mnt</span>`;
            }
        }
    });
});

// Helper Functions
function openModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.add('active');
}

function closeModal(modalId) {
    const m = document.getElementById(modalId);
    if (m) m.classList.remove('active');
}

// Function to populate Ubah Jadwal modal
function openEditScheduleModal(scheduleId, courseName, day, startTime, endTime, room, status, notes) {
    document.getElementById('edit_schedule_form').action = `/schedule/${scheduleId}/edit`;
    document.getElementById('edit_modal_course_name').innerText = courseName;
    document.getElementById('edit_day').value = day;
    document.getElementById('edit_start_time').value = startTime;
    document.getElementById('edit_end_time').value = endTime;
    document.getElementById('edit_room').value = room;
    document.getElementById('edit_status').value = status || 'Jadwal Diubah / Rescheduled';
    document.getElementById('edit_notes').value = notes || '';
    document.getElementById('edit_reason').value = '';
    openModal('editScheduleModal');
}

// Function to populate Ingatkan Tugas modal (for PJ)
function openRemindModal(assignmentId, courseName, assignmentTitle, deadline) {
    document.getElementById('remind_form').action = `/assignment/${assignmentId}/remind`;
    document.getElementById('remind_modal_course').innerText = courseName;
    document.getElementById('remind_modal_title').innerText = assignmentTitle;
    document.getElementById('remind_modal_deadline').innerText = deadline;
    document.getElementById('remind_custom_note').value = 'Halo rekan-rekan, jangan lupa batas pengumpulan tugas ini semakin dekat. Harap segera diselesaikan sebelum deadline!';
    openModal('remindTaskModal');
}

