# Reclass.UM - Portal Reschedule Jadwal Kuliah & Sinkronisasi Google Calendar

Portal web perkuliahan modern yang memfasilitasi koordinasi perkuliahan antara **Dosen**, **Penanggung Jawab Mata Kuliah (PJ Matkul)**, dan **Mahasiswa**, dilengkapi dengan **notifikasi email otomatis** dan **sinkronisasi langsung ke Google Calendar** setiap ada perubahan jadwal atau penambahan tugas.

---

## 🌟 Fitur Utama

1. **Autentikasi Multi-Role**:
   - **Dosen**:
     - Mengubah jadwal perkuliahan (Hari, Jam, Ruang/Platform Online, Status: Normal / Rescheduled / Online / Batal, Catatan).
     - Menginput tugas baru (Judul, Deskripsi, Tenggat Waktu / Deadline, Link Pengumpulan).
     - Melihat daftar mahasiswa yang mengambil mata kuliah.
   - **PJ Matkul (Penanggung Jawab Kelas)**:
     - Mengajukan / mengubah jadwal kuliah pengganti hasil kesepakatan kelas.
     - Mengirimkan *Broadcast Email Reminder* ("Ingatkan Tugas") kepada seluruh mahasiswa peserta kelas.
   - **Mahasiswa**:
     - Registrasi akun mahasiswa (Nama, NIM, Email aktif).
     - Memilih / mengambil mata kuliah (*Enrollment*).
     - Memantau perubahan jadwal dengan indikator visual komparasi (*Jadwal Semula* vs *Jadwal Baru*).
     - Melihat daftar tugas aktif beserta live countdown timer menuju deadline.
     - Tombol 1-klik untuk plot jadwal dan tugas langsung ke Google Calendar pribadi & download file undangan `.ics`.

2. **Notifikasi Email & Integrasi Google Calendar**:
   - **Auto-Plotting Google Calendar**:
     - Dilengkapi generator file undangan kalender standar **iCalendar RFC 5545 (`.ics`)** dengan metode `REQUEST`. Gmail secara cerdas otomatis mendeteksi file ini pada email masuk dan langsung memplot jadwal ke Google Calendar akun pengguna!
     - Tombol interaktif **"Simpan ke Google Calendar"** langsung di dalam email dan halaman web. Sekali klik, event langsung terbuka di Google Calendar dengan judul, lokasi, dan jam yang presisi.
   - **In-App Outbox Inspector**:
     - Seluruh riwayat email yang dikirim sistem tersimpan dan dapat diinspeksi secara visual melalui menu **📬 Log Email & Kalender** (`/outbox`).

---

## 🚀 Cara Menjalankan Aplikasi

Pastikan Anda berada di direktori proyek:
```bash
cd /home/jimmy/.gemini/antigravity/scratch/jadwal_kuliah_app
```

Jalankan server menggunakan runner:
```bash
./run.sh
```
Atau via venv:
```bash
./venv/bin/python app.py
```

Aplikasi akan berjalan di: **`http://localhost:5000`**

---

## 🔑 Akun Demo Siap Pakai (Password Default: `password123`)

Aplikasi telah dilengkapi dengan data sampel awal (Seed Data). Setiap pengguna dapat masuk menggunakan email terdaftar dan kata sandi, serta dapat mengelola profil dan mengganti kata sandi di menu **Profil Saya** (`/profile`):

| Role | Nama | Email | NIM / NIP | Mata Kuliah / Wewenang |
| :--- | :--- | :--- | :--- | :--- |
| **Admin** | Admin Akademik UM | `admin@um.ac.id` | ADM001 | Akses Penuh: Kelola Matkul, Dosen, Mahasiswa, Jadwal |
| **Dosen** | Dr. Budi Santoso, M.T. | `dosen1@kampus.ac.id` | 198001012005011001 | IF301 (Pemrograman Web), IF303 (RPL) |
| **Dosen** | Siti Nurhaliza, M.Kom. | `dosen2@kampus.ac.id` | 198502022008012002 | IF302 (Basis Data Terdistribusi) |
| **PJ Matkul** | Ahmad Rizki (PJ) | `pj.pemweb@mhs.kampus.ac.id` | 220101001 | PJ IF301 & IF303 |
| **PJ Matkul** | Dewi Lestari (PJ) | `pj.basdat@mhs.kampus.ac.id` | 220101002 | PJ IF302 |
| **Mahasiswa** | Bambang Prakoso | `mhs1@mhs.kampus.ac.id` | 220101010 | Terdaftar di IF301, IF302, IF303 |
| **Mahasiswa** | Putri Indah | `mhs2@mhs.kampus.ac.id` | 220101011 | Terdaftar di IF301, IF302 |

---

## ⚙️ Konfigurasi Email Nyata (SMTP Gmail)

Secara default, aplikasi berjalan dalam mode **Simulasi Outbox**, di mana semua email, file `.ics`, dan template HTML dapat diinspeksi langsung di menu `/outbox` tanpa memerlukan koneksi internet.

Jika Anda ingin mengaktifkan pengiriman email sungguhan ke email Gmail mahasiswa:
1. Buka file `.env`.
2. Ubah `ENABLE_REAL_EMAIL=true`.
3. Masukkan App Password Gmail Anda (buat di *Google Account > Security > 2-Step Verification > App Passwords*):
   ```ini
   ENABLE_REAL_EMAIL=true
   SMTP_SERVER=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USERNAME=email_anda@gmail.com
   SMTP_PASSWORD=xxxx_xxxx_xxxx_xxxx
   SMTP_SENDER_EMAIL=email_anda@gmail.com
   SMTP_SENDER_NAME=Portal Akademik Jadwal & Tugas
   ```

---

## 📂 Struktur Proyek

```
jadwal_kuliah_app/
├── app.py                      # Flask Application Controller & Routing
├── config.py                   # Konfigurasi aplikasi & environment
├── database.py                 # SQLite database helper & schema creation
├── models.py                   # Query data & relasi antarmuka
├── seed_data.py                # Data default (Dosen, PJ, Mahasiswa, Matkul)
├── services/
│   ├── auth_service.py         # Autentikasi, role guard, dan hashing password
│   ├── calendar_service.py     # Generator link Google Calendar & file .ics RFC 5545
│   └── email_service.py        # Dispatcher email notifikasi & in-app outbox
├── static/
│   ├── css/style.css           # Styling CSS modern & responsif
│   └── js/app.js               # Handler modal, deadline countdown, autologin
├── templates/
│   ├── base.html               # Layout umum & navigasi
│   ├── login.html              # Form login + tombol 1-klik Quick Demo
│   ├── register.html           # Registrasi mahasiswa
│   ├── dashboard_dosen.html    # Dashboard dosen (Ubah jadwal, input tugas)
│   ├── dashboard_pj.html       # Dashboard PJ (Ubah jadwal, blast pengingat)
│   ├── dashboard_mhs.html      # Dashboard mahasiswa (Lihat perubahan & sync GCal)
│   ├── course_detail.html      # Detail kelas, daftar mahasiswa, log riwayat
│   └── outbox.html             # Inspeksi email terkirim & preview HTML
├── .env                        # Konfigurasi aktif
├── .env.example                # Template konfigurasi
├── requirements.txt            # Dependensi Python
└── run.sh                      # Script runner
```
